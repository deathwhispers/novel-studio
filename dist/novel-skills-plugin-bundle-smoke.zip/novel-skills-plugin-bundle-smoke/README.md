# Novel Skills Local Plugin Bundle

Build timestamp: 20260628-233157
Source commit: 8b8e073927db

## Install

1. Unzip this bundle.
2. Run `python3 install_codex_plugin.py`.
3. Restart Codex if it is already open.
4. Start a new thread before testing.

## What The Installer Does

- Registers this directory as a local Codex marketplace with `codex plugin marketplace add`.
- Copies the plugin into `~/.codex/plugins/cache/novel-local/novel-skills/<version>`.
- Ensures `[features] plugins = true` is set in `~/.codex/config.toml`.
- Enables `novel-skills@novel-local` in `~/.codex/config.toml`.

## Test Prompt

```text
Use novel-studio to route my current fiction-writing task.
```

## Uninstall

Run `python3 uninstall_codex_plugin.py`.
