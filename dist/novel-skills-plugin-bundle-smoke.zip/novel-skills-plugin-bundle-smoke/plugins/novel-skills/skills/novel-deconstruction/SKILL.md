---
name: novel-deconstruction
description: "中文小说拆文 skill。用于拆解样章、黄金三章、爆款长篇、爆款短篇或用户已有稿件，从中提取钩子、人设、节奏、爽点、虐点、回收结构、语言习惯和商业化技巧。适用于“帮我拆这本书”“分析这篇短篇为什么有效”“提炼这个作者的开篇打法”“把这本爆款小说拆成可复用技法”等场景。"
---

# Novel Deconstruction

## Overview

拆文的目标不是复制，而是抽取可迁移的方法。优先分析结构和读者感受机制，而不是堆摘要。

尤其要为后续写作服务：拆出逻辑链、场景因果、细节载体、伏笔回收和信息推进方式，而不只是评价“好看”。

## 拆文层级

1. 黄金开篇
   - 标题
   - 简介
   - 前三章或前 3000-5000 字
2. 结构层
   - 主角引入
   - 冲突升级
   - 爽点/痛点兑现
   - 悬念布置与回收
3. 文风层
   - 句长
   - 对话密度
   - 细节颗粒度
   - 情绪推进方式

## 输出要求

至少输出：

- 这部作品卖点是什么
- 它如何在开篇抓人
- 它如何维持追读或完读
- 它最值得借鉴的 5-10 个写法动作
- 哪些部分只能学机制，不能照搬表层
- 它如何保证逻辑不断裂
- 它靠什么细节让场景成立

优先按 `references/deconstruction-output-spec.md` 的结构落盘。若当前是小说项目工作区，默认写入：

- `05-market/deconstructions/{对标名}-analysis.md`

如需参照完成态，读取：

- `assets/examples/benchmark-analysis-example.md`
- `assets/examples/golden-hook-example.md`
- `assets/examples/long-form/retention-analysis-example.md`
- `assets/examples/short-form/compression-analysis-example.md`

## 长短篇差异

- 长篇拆文优先看留存、升级、关系网和章节钩子
- 短篇拆文优先看题眼、反转、情绪压缩和结尾回响

## 质量优先级

拆文时优先提取：

1. 因果链是否闭合
2. 场景目标是否明确
3. 细节如何承载情绪与信息
4. 伏笔如何投放、延迟和回收
5. 读者为什么愿意继续读下一段或下一章

## 资源

- 长短篇拆文重点：`references/deconstruction-modes.md`
- 可迁移技法清单：`references/pattern-catalog.md`
- 输出模板：`references/deconstruction-output-spec.md`
- 逻辑与细节检查：`references/quality-lenses.md`
