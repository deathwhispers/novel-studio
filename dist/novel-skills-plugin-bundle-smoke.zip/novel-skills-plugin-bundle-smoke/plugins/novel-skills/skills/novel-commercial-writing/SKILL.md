---
name: novel-commercial-writing
description: "中文小说商业化写作 skill。用于把创意、大纲或正文转成更有市场阅读效率的版本，重点处理书名、简介、开篇钩子、追读点、爽点兑现、付费前后节奏、角色关系引擎和平台适配。适用于“这本书怎么更能卖”“帮我做商业化改造”“提升追读感”“让这篇更像平台爆款”“优化书名简介和开篇” 等场景。"
---

# Novel Commercial Writing

## Overview

商业化不是媚俗，而是提高可读性、可传播性和兑现效率。这个 skill 负责把“能写”推向“更可能被读下去”。

## 核心问题

每次都先回答：

1. 读者为什么点开
2. 读者为什么继续看
3. 读者为什么愿意付出时间或付费
4. 这本书靠什么和同类区分

## 重点优化对象

- 书名
- 简介
- 开篇 3 章
- 角色卖点
- 关系 tension
- 节奏兑现
- 章节尾钩

## 长篇与短篇的商业差异

- 长篇更看追读循环、升级梯度、关系延展和持续兑现
- 短篇更看题眼清晰、情绪压缩、反转力度和分享传播感

## 输出要求

至少给出：

- 当前稿件的商业风险点
- 最值得优先优化的 3 个位置
- 可直接落地的修改方向
- 如果需要，转给 `novel-market-scan`、`novel-outlining` 或 `novel-deslop`

## 资源

- 商业化指标：`references/commercial-checklist.md`
- 平台适配：`references/platform-fit.md`
- 开篇与留存：`references/retention-loops.md`
