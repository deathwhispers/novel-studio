# Prewrite

写章节或关键场景前，先复制 `chapter-prewrite-checklist.md`，按章节或场景改名后填写。

如果空项太多，先回到大纲、连续性文件或拆文结果补齐，不要直接硬写正文。
